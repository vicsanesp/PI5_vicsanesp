package datos;

public class datosEj2 {

}
