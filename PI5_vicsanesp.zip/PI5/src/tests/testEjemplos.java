package tests;

import java.io.IOException;
import java.util.List;

import datos.datosEjemplo1;
import datos.datosEjemplo2;
import us.lsi.common.Files2;
import us.lsi.common.String2;
import us.lsi.gurobi.GurobiLp;
import us.lsi.gurobi.GurobiSolution;
import us.lsi.solve.AuxGrammar;

public class testEjemplos {

	public static void main(String[] args) {
		testEjemplo1();
		
	}
	
	public static void testEjemplo1() {
		List<String> lineas = Files2.linesFromFile("ficherosEjemplos/Ejemplo1DatosEntrada.txt");
		for (int i = 0; i < lineas.size(); i++) {
			datosEjemplo1.iniDatos(lineas.get(i));
			
			
			String ficheroGurobi = "modelosGurobi/Ejemplo1_"+(i+1)+".lp";
			try {
				AuxGrammar.generate(datosEjemplo1.class, "modeloslsi/Ejemplo1.lsi", ficheroGurobi);
			}
			catch(IOException e) {
				e.printStackTrace();
			}
			GurobiSolution gs = GurobiLp.gurobi(ficheroGurobi);
			String2.toConsole("%s\n%s\n", gs.toString((k,v)->v>0), String2.linea());
		}
	}
	
	public static void testEjemplo2() {
		List<String> lineas = Files2.linesFromFile("ficherosEjemplos/Ejemplo2DatosEntrada.txt");
		for (int i = 0; i < lineas.size(); i++) {
			datosEjemplo1.iniDatos(lineas.get(i));
			
			
			String ficheroGurobi = "modelosGurobi/Ejemplo2_"+(i+1)+".lp";
			try {
				AuxGrammar.generate(datosEjemplo2.class, "modeloslsi/Ejemplo2.lsi", ficheroGurobi);
			}
			catch(IOException e) {
				e.printStackTrace();
			}
			GurobiSolution gs = GurobiLp.gurobi(ficheroGurobi);
			String2.toConsole("%s\n%s\n", gs.toString((k,v)->v>0), String2.linea());
		}
	}

}
