module PI5 {
	requires transitive grafos;
	requires geneticos;
	requires solve;
	
	exports datos;
}