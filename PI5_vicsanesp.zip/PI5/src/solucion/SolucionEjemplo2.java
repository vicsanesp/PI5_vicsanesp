package solucion;

public class SolucionEjemplo2 {

}
