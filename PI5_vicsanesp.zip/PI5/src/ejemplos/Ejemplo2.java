package ejemplos;

public class Ejemplo2 {

}
