package datos;

import java.util.List;
import java.util.Set;

import us.lsi.common.Files2;
import us.lsi.common.List2;
import us.lsi.common.Set2;
import us.lsi.common.String2;

public class datosEjemplo2 {
	public static record Subconjunto(Double peso, Set<Integer> elems) {
		public static Subconjunto of(String line) {
			String[] v = line.split(":");
			Double w = Double.parseDouble(v[1].trim());
			Set<Integer> s = Set2.parse(v[0], "{,}", Integer::parseInt);
			return new Subconjunto(w, s);
		}
		public String toSTring() {
			return elems + ": " + peso;
		}
	}
	
	private static List<Integer> universo;
	private static List<Subconjunto> ls;
	
	public static void main(String[] args) {
		iniDatos("ficherosEjemplos/Ejemplo2DatosEntrada1.txt");
	}
	
	public static void iniDatos(String fichero) {
		ls = List2.empty();
		Set<Integer> aux = Set2.empty();
		Files2.streamFromFile(fichero).forEach(linea->{
			Subconjunto s = Subconjunto.of(linea);
			ls.add(s);
			aux.addAll(s.elems);
		});
		universo = List2.ofCollection(aux);
		toConsole();	
	}
	
	public static void toConsole() {
		String2.toConsole("Universo = %s", universo);
		String2.toConsole(ls, "Subconjuntos");
	}
	
	public static Integer getN() {
		return universo.size();
	}
	
	public static Integer getM() {
		return ls.size();
	}
	
	public static Double getW(Integer i) {
		return ls.get(i).peso();
	}
	
	public static Integer getC(Integer i, Integer j) {
		if(ls.get(i).elems().contains(universo.get(j))) {
			return 1;
		}else {
			return 0;
		}
		
	}

}
