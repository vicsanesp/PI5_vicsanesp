package datos;

import java.util.List;

import us.lsi.common.Files2;
import us.lsi.common.List2;
import us.lsi.common.String2;

public class datosEjemplo3 {

	public static record Alumno(String nombre, List<Integer> afinidades) {
		public static Alumno of(String s) {
			String[] v = s.split(":");
			return new Alumno(v[0].trim(), List2.parse(v[1].trim(), ",", Integer::parseInt));
		}
		public String toString() {
			return nombre + ": " + afinidades;
		}
	}
	
	public static void iniDatos(String fichero) {
		alumnos = List2.empty();
		Files2.streamFromFile(fichero).forEach(linea -> alumnos.add(Alumno.of(linea)));
		String2.toConsole(alumnos, "Contenido del fichero: ");
	}
	private static List<Alumno> alumnos;
	
	public static Integer getN() {
		return alumnos.size();
	}
	public static Integer getM() {
		return alumnos.get(0).afinidades().size();
	}
	public static Integer getT() {
		return getN()/getM();
	}
	public static Integer getA(Integer i, Integer j) {
		return alumnos.get(i).afinidades().get(j);
	}
	
	public static void main(String[] args) {
		iniDatos("ficherosEjemplos/Ejemplo3DatosEntrada1.txt");
	}
	public static String getNombre(int i) {
		return alumnos.get(i).nombre();
	}
}

