package datos;

import java.util.List;

import us.lsi.common.Files2;
import us.lsi.common.List2;
import us.lsi.common.String2;

public class datosEjemplo1 {
	
	public static void main(String[] args) {
		Files2.streamFromFile("ficherosEjemplos/Ejemplo1DatosEntrada.txt")
		.forEach(linea -> iniDatos(linea));
	}
	
	private static Integer n;
	private static List<Integer> s;
	
	public static Integer getN() {
		return n;
	}
	public static Integer getM() {
		return s.size();
	}
	public static Integer getE(Integer i) {
		return s.get(i);
	}
	public static Integer getMU(Integer i) {
		return n/getE(i);
	}
	
	public static void iniDatos(String linea) {
		String[] v = linea.split(":");
		n = Integer.parseInt(v[1].trim());
		s = List2.parse(v[0], ",", Integer::parseInt);
		toConsole();
	}
	
	public static void toConsole() {
		String2.toConsole("n=%d\ns=%s\n%s", n, s, String2.linea());
	}

}
