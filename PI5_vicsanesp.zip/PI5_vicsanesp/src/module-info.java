module PI5_vicsanesp {
	requires transitive grafos;
	requires geneticos;
	requires solve;
	
	exports datos;
}