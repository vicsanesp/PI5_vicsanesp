package tests;

import java.io.IOException;
import java.util.List;

import datos.datosEjemplo1;
import datos.datosEjemplo2;
import datos.datosEjemplo3;
import geneticos.Ejemplo3Geneticos;
import us.lsi.ag.agchromosomes.AlgoritmoAG;
import us.lsi.ag.agstopping.StoppingConditionFactory;
import us.lsi.common.Files2;
import us.lsi.common.String2;
import us.lsi.gurobi.GurobiLp;
import us.lsi.gurobi.GurobiSolution;
import us.lsi.solve.AuxGrammar;

public class testEjemplos {

	public static void main(String[] args) {
//		testEjemplo1();
//		tesEjemplo3PLE();
		testEjemplo3Genetico();
	}
	
	public static void testEjemplo1() {
		List<String> lineas = Files2.linesFromFile("ficherosEjemplos/Ejemplo1DatosEntrada.txt");
		for (int i = 0; i < lineas.size(); i++) {
			datosEjemplo1.iniDatos(lineas.get(i));
			
			
			String ficheroGurobi = "modelosGurobi/Ejemplo1_"+(i+1)+".lp";
			try {
				AuxGrammar.generate(datosEjemplo1.class, "modeloslsi/Ejemplo1.lsi", ficheroGurobi);
			}
			catch(IOException e) {
				e.printStackTrace();
			}
			GurobiSolution gs = GurobiLp.gurobi(ficheroGurobi);
			String2.toConsole("%s\n%s\n", gs.toString((k,v)->v>0), String2.linea());
		}
	}
	
//	public static void testEjemplo2() {
//		List<String> lineas = Files2.linesFromFile("ficherosEjemplos/Ejemplo2DatosEntrada.txt");
//		for (int i = 0; i < lineas.size(); i++) {
//			datosEjemplo1.iniDatos(lineas.get(i));
//			
//			
//			String ficheroGurobi = "modelosGurobi/Ejemplo2_"+(i+1)+".lp";
//			try {
//				AuxGrammar.generate(datosEjemplo2.class, "modeloslsi/Ejemplo2.lsi", ficheroGurobi);
//			}
//			catch(IOException e) {
//				e.printStackTrace();
//			}
//			GurobiSolution gs = GurobiLp.gurobi(ficheroGurobi);
//			String2.toConsole("%s\n%s\n", gs.toString((k,v)->v>0), String2.linea());
//		}
//	}
	public static void tesEjemplo3PLE() {
		datosEjemplo3.iniDatos("ficherosEjemplos/Ejemplo3DatosEntrada1.txt");
		String flsi = "modeloslsi/Ejemplo3.lsi";
		String fg = "modelosGurobi/Ejemplo3.lp";
		try {
			AuxGrammar.generate(datosEjemplo3.class, flsi, fg);
		}catch(IOException e) {
			e.printStackTrace();
		}
		GurobiSolution gs = GurobiLp.gurobi(fg);
//		System.out.println(gs.toString((k,v)->v>0));
		
	}
	
	public static void testEjemplo3Genetico() {
		AlgoritmoAG.POPULATION_SIZE = 200;
		StoppingConditionFactory.NUM_GENERATIONS = 400;
		datosEjemplo3.iniDatos("ficherosEjemplos/Ejemplo3DatosEntrada1.txt");
		var alg = AlgoritmoAG.of(new Ejemplo3Geneticos());
		alg.ejecuta();
		System.out.println(alg.bestSolution());
	}
	
	
	

}
