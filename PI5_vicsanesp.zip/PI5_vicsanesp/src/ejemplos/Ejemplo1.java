package ejemplos;

public class Ejemplo1 {

}
