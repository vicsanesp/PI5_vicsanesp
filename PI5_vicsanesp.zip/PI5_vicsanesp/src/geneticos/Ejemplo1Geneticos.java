package geneticos;

import java.util.List;

import datos.datosEjemplo1;
import solucion.SolucionEjemplo1;
import us.lsi.ag.ValuesInRangeData;
import us.lsi.ag.agchromosomes.ChromosomeFactory.ChromosomeType;

public class Ejemplo1Geneticos implements ValuesInRangeData<Integer, SolucionEjemplo1>{

	public static Ejemplo1Geneticos of(String linea) {
		datosEjemplo1.iniDatos(linea);
		return new Ejemplo1Geneticos();
	}
	@Override
	public Integer size() {
		return datosEjemplo1.getM();
	}

	@Override
	public ChromosomeType type() {
		return ChromosomeType.Range;
	}

	@Override
	public Double fitnessFunction(List<Integer> cr) {
		//premia aciertos y penaliza errores
		Double goal = 0.;
		Double sum = 0.;
		for(int i = 0; i<cr.size(); i++) {
			goal += cr.get(i);
			sum += cr.get(i)*datosEjemplo1.getE(i);
		}
		double error = Math.abs(sum - datosEjemplo1.getN());
		//saco diferencia entre el que tengo y el valor objetivo
		if(error<1) {
			//si el error es mayor que uno la solucion no vale
			return -goal;
			//signo menos porque estamos minimizando
		}
		else {
			return -100000*error;
		}
	}

	@Override
	public SolucionEjemplo1 solucion(List<Integer> cr) {
		return SolucionEjemplo1.of(cr);
	}

	@Override
	public Integer max(Integer i) {
		return datosEjemplo1.getMU(i)+1;
	}

	@Override
	public Integer min(Integer i) {
		return 0;
	}

}
