package geneticos;

public class Ejemplo2Geneticos{

}
