package geneticos;

import java.util.List;

import datos.datosEjemplo3;
import solucion.SolucionEjemplo3;
import us.lsi.ag.ValuesInRangeData;
import us.lsi.ag.agchromosomes.ChromosomeFactory.ChromosomeType;

public class Ejemplo3Geneticos implements ValuesInRangeData<Integer, SolucionEjemplo3>{

	@Override
	public Integer size() {
		return datosEjemplo3.getN();
	}

	@Override
	public ChromosomeType type() {
		return ChromosomeType.Range;
	}

	@Override
	public Double fitnessFunction(List<Integer> cr) {
		double goal = 0;
		double error = 0;
		int[] v = new int[datosEjemplo3.getM()];
		for (int i = 0; i < size(); i++) {
			int j = cr.get(i);
			int a = datosEjemplo3.getA(i, j);
			 goal += a;
			 if(a == 0) {
				 error += 1;
			 }
			 else {
				 error += 0;
			 }
			 v[j]++;
		}
		for(int e: v) {
			error += Math.abs(e - datosEjemplo3.getT());
		}
		if(error<1) {
			return goal;
		}
		else {
			return -100000*error;
		}
	}

	@Override
	public SolucionEjemplo3 solucion(List<Integer> cr) {
		SolucionEjemplo3 res = SolucionEjemplo3.empty();
		for(int i=0; i<size(); i++) {
			int j = cr.get(i);
			res.add(i, j);
		}
		return res;
	}

	@Override
	public Integer max(Integer i) {
		return datosEjemplo3.getM()-1;
	}

	@Override
	public Integer min(Integer i) {
		return 0;
	}

}
