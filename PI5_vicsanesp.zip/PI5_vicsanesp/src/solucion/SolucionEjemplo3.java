package solucion;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import datos.datosEjemplo3;
import us.lsi.common.List2;
import us.lsi.common.Map2;

public class SolucionEjemplo3 {

	public static SolucionEjemplo3 empty() {
		return new SolucionEjemplo3();
	}
	Integer afTotal;
	Map<Integer, List<String>>reparto;
	private SolucionEjemplo3() {
		afTotal = 0;
		reparto = Map2.empty();
	}
	
	public void add(int i, int j) {
		afTotal += datosEjemplo3.getA(i, j);
		if(reparto.containsKey(j)) {
			reparto.get(j).add(datosEjemplo3.getNombre(i));
		}
		else {
			reparto.put(j, List2.of(datosEjemplo3.getNombre(i)));
		}
	}
	public String toString() {
		String sf = String.format("\nAfinidad total: %d", afTotal);
		return reparto.entrySet().stream().map(e -> "Grupo" + e.getKey() + ": " + e.getValue()).collect(Collectors.joining("\n", "Reparto obtenido:\n", sf));
	}
}
