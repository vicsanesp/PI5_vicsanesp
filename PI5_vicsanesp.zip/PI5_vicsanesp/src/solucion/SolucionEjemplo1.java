package solucion;

import java.util.List;

import datos.datosEjemplo1;
import us.lsi.common.Multiset;

public class SolucionEjemplo1 {

	private Multiset<Integer> solucion;
	private Integer total_elems;
	private Integer suma;
	
	private SolucionEjemplo1(Multiset<Integer> ms, Integer n, Integer s) {
		solucion = ms;
		total_elems = n;
		suma = s;
	}
	
	public static SolucionEjemplo1 of(List<Integer> cr) {
		Multiset<Integer> ms = Multiset.empty();
		Integer total = 0;
		Integer sum = 0;
		for (int i = 0; i < cr.size(); i++) {
			ms.add(datosEjemplo1.getE(i), cr.get(i));
			total += cr.get(i);
			sum += datosEjemplo1.getE(i)*cr.get(i);
		}
		return new SolucionEjemplo1(ms, total, sum);
	}

	@Override
	public String toString() {
		return "SolucionEjemplo1 [solucion=" + solucion + ", total_elems=" + total_elems + ", suma=" + suma + "]";
	}
	
}
